package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ui.Screen
import com.example.ui.ScreenshotViewModel
import com.example.ui.components.*
import com.example.ui.screens.CollectionsScreen
import com.example.ui.screens.DetailScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.theme.MyApplicationTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                }

                val permissionState = rememberMultiplePermissionsState(permissions)

                if (permissionState.allPermissionsGranted) {
                    MainApp()
                } else {
                    PermissionScreen(
                        onRequest = { permissionState.launchMultiplePermissionRequest() }
                    )
                }
            }
        }
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit) {
    AmbientBackground {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            LiquidGlassCard(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .padding(24.dp),
                elevation = 20.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("✨", style = MaterialTheme.typography.displayMedium)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "Screenshot Memory",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "We need permission to access your device images so we can discover, OCR-index, and curate your screenshot memories into an interactive visual gallery.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    LiquidGlassButton(
                        text = "Grant Image Permission",
                        onClick = onRequest,
                        primary = true
                    )
                }
            }
        }
    }
}

@Composable
fun MainApp() {
    val navController = rememberNavController()
    val viewModel: ScreenshotViewModel = viewModel()

    LaunchedEffect(Unit) {
        viewModel.scanAndProcess()
    }

    val currentBackStack by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStack?.destination?.route

    AmbientBackground {
        NavHost(
            navController = navController,
            startDestination = Screen.Home,
            enterTransition = { fadeIn(animationSpec = tween(350)) + scaleIn(initialScale = 0.96f, animationSpec = tween(350)) },
            exitTransition = { fadeOut(animationSpec = tween(250)) + scaleOut(targetScale = 1.04f, animationSpec = tween(250)) },
            popEnterTransition = { fadeIn(animationSpec = tween(350)) + scaleIn(initialScale = 1.04f, animationSpec = tween(350)) },
            popExitTransition = { fadeOut(animationSpec = tween(250)) + scaleOut(targetScale = 0.96f, animationSpec = tween(250)) }
        ) {
            composable<Screen.Home> {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToSearch = { navController.navigate(Screen.Search) },
                    onNavigateToDetail = { id -> navController.navigate(Screen.Detail(id)) }
                )
            }
            composable<Screen.Search> {
                SearchScreen(
                    viewModel = viewModel,
                    onNavigateToDetail = { id -> navController.navigate(Screen.Detail(id)) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable<Screen.Collections> {
                CollectionsScreen(
                    viewModel = viewModel,
                    onNavigateToDetail = { id -> navController.navigate(Screen.Detail(id)) }
                )
            }
            composable<Screen.Favorites> {
                FavoritesScreen(
                    viewModel = viewModel,
                    onNavigateToDetail = { id -> navController.navigate(Screen.Detail(id)) }
                )
            }
            composable<Screen.Detail> { backStackEntry ->
                val detail: Screen.Detail = backStackEntry.toRoute()
                DetailScreen(
                    screenshotId = detail.screenshotId,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onNavigateToSearch = { navController.navigate(Screen.Search) }
                )
            }
        }

        // Floating Liquid Glass Navigation Dock
        if (currentRoute?.contains("Detail") != true) {
            LiquidGlassSurface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 20.dp, vertical = 20.dp)
                    .navigationBarsPadding(),
                shape = RoundedCornerShape(36.dp),
                elevation = 20.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavDockItem(
                        icon = Icons.Default.Home,
                        label = "Home",
                        selected = currentRoute?.contains("Home") == true,
                        onClick = {
                            navController.navigate(Screen.Home) {
                                launchSingleTop = true
                                popUpTo(navController.graph.startDestinationId) { inclusive = false }
                            }
                        }
                    )

                    NavDockItem(
                        icon = Icons.Default.Search,
                        label = "Search",
                        selected = currentRoute?.contains("Search") == true,
                        onClick = {
                            navController.navigate(Screen.Search) {
                                launchSingleTop = true
                                popUpTo(navController.graph.startDestinationId) { inclusive = false }
                            }
                        }
                    )

                    NavDockItem(
                        icon = Icons.Default.Folder,
                        label = "Collections",
                        selected = currentRoute?.contains("Collections") == true,
                        onClick = {
                            navController.navigate(Screen.Collections) {
                                launchSingleTop = true
                                popUpTo(navController.graph.startDestinationId) { inclusive = false }
                            }
                        }
                    )

                    NavDockItem(
                        icon = Icons.Default.Favorite,
                        label = "Favorites",
                        selected = currentRoute?.contains("Favorites") == true,
                        onClick = {
                            navController.navigate(Screen.Favorites) {
                                launchSingleTop = true
                                popUpTo(navController.graph.startDestinationId) { inclusive = false }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun NavDockItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .bouncingClickable(onClick = onClick)
            .clip(RoundedCornerShape(24.dp))
            .background(
                if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent
            )
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                modifier = Modifier.size(22.dp)
            )
            if (selected) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
