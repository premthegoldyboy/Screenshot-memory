package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AmbientBackground(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable BoxScope.() -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient")
    val offset1 by infiniteTransition.animateFloat(
        initialValue = -300f, targetValue = 1200f,
        animationSpec = infiniteRepeatable(tween(22000, easing = LinearEasing), RepeatMode.Reverse),
        label = "offset1"
    )
    val offset2 by infiniteTransition.animateFloat(
        initialValue = 1200f, targetValue = -300f,
        animationSpec = infiniteRepeatable(tween(28000, easing = LinearEasing), RepeatMode.Reverse),
        label = "offset2"
    )

    val bgColor = if (darkTheme) Color(0xFF090A0F) else Color(0xFFF7F8FC)

    Box(modifier = Modifier.fillMaxSize().background(bgColor)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val color1 = if (darkTheme) Color(0x331E3A8A) else Color(0x2B93C5FD) // Royal blue tint
            val color2 = if (darkTheme) Color(0x2B3B0764) else Color(0x2BC084FC) // Lavender tint
            val color3 = if (darkTheme) Color(0x22064E3B) else Color(0x266EE7B7) // Mint tint
            val color4 = if (darkTheme) Color(0x2B4C1D95) else Color(0x22FDBA74) // Warm peach tint

            drawCircle(
                brush = Brush.radialGradient(listOf(color1, Color.Transparent)),
                radius = size.maxDimension * 0.65f,
                center = Offset(offset1, offset2)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(color2, Color.Transparent)),
                radius = size.maxDimension * 0.75f,
                center = Offset(size.width - offset2, size.height - offset1)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(color3, Color.Transparent)),
                radius = size.maxDimension * 0.55f,
                center = Offset(size.width / 2 + offset1 / 2, size.height / 2 - offset2 / 2)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(color4, Color.Transparent)),
                radius = size.maxDimension * 0.70f,
                center = Offset(size.width / 2 - offset1 / 2, size.height / 2 + offset2 / 2)
            )
        }
        content()
    }
}

@Composable
fun Modifier.bouncingClickable(
    enabled: Boolean = true,
    onClick: () -> Unit
): Modifier {
    var isPressed by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "scale"
    )

    return this
        .scale(scale)
        .pointerInput(enabled) {
            if (enabled) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        tryAwaitRelease()
                        isPressed = false
                    },
                    onTap = {
                        onClick()
                    }
                )
            }
        }
}

@Composable
fun LiquidGlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    elevation: Dp = 12.dp,
    tintColor: Color? = null,
    borderAlpha: Float = 0.4f,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val baseTint = tintColor ?: if (isDark) Color(0x29FFFFFF) else Color(0xCCFFFFFF)
    val specularTop = if (isDark) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.85f)
    val specularBottom = if (isDark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.20f)

    val surfaceBrush = Brush.verticalGradient(
        colors = listOf(
            baseTint,
            baseTint.copy(alpha = (baseTint.alpha * 0.75f).coerceIn(0f, 1f))
        )
    )

    val borderBrush = Brush.verticalGradient(
        colors = listOf(
            specularTop.copy(alpha = borderAlpha),
            specularBottom.copy(alpha = borderAlpha * 0.3f)
        )
    )

    Box(
        modifier = modifier
            .shadow(elevation, shape, spotColor = if (isDark) Color.Black else Color(0x20000000), ambientColor = Color.Transparent)
            .clip(shape)
            .background(surfaceBrush)
            .border(1.dp, borderBrush, shape),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

// Backward compatibility alias
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    color: Color = Color.Unspecified,
    borderColor: Color = Color.Unspecified,
    elevation: Dp = 12.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val tint = if (color != Color.Unspecified) color else null
    LiquidGlassSurface(
        modifier = modifier,
        shape = shape,
        elevation = elevation,
        tintColor = tint,
        content = content
    )
}

@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    elevation: Dp = 10.dp,
    tintColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val clickModifier = if (onClick != null) Modifier.bouncingClickable(onClick = onClick) else Modifier
    LiquidGlassSurface(
        modifier = modifier.then(clickModifier),
        shape = shape,
        elevation = elevation,
        tintColor = tintColor
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun LiquidGlassToolbar(
    title: String,
    modifier: Modifier = Modifier,
    navigationIcon: (@Composable () -> Unit)? = null,
    actions: (@Composable RowScope.() -> Unit)? = null
) {
    LiquidGlassSurface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        elevation = 16.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                navigationIcon?.invoke()
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            if (actions != null) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    actions()
                }
            }
        }
    }
}

@Composable
fun LiquidGlassSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    placeholderText: String = "Search anything in your screenshots...",
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null
) {
    val clickModifier = if (onClick != null) Modifier.bouncingClickable(onClick = onClick) else Modifier

    LiquidGlassSurface(
        modifier = modifier
            .fillMaxWidth()
            .then(clickModifier),
        shape = RoundedCornerShape(32.dp),
        elevation = 16.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (leadingIcon != null) {
                leadingIcon()
                Spacer(modifier = Modifier.width(12.dp))
            } else {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(12.dp))
            }

            if (onClick != null) {
                Text(
                    text = if (query.isEmpty()) placeholderText else query,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (query.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
            } else {
                TextField(
                    value = query,
                    onValueChange = onQueryChange,
                    placeholder = {
                        Text(
                            placeholderText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            if (trailingIcon != null) {
                trailingIcon()
            } else if (query.isNotEmpty() && onClick == null) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun LiquidGlassChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    badgeCount: Int? = null
) {
    val isDark = isSystemInDarkTheme()
    val activeTint = MaterialTheme.colorScheme.primary.copy(alpha = if (isDark) 0.35f else 0.18f)
    val inactiveTint = if (isDark) Color(0x1AFFFFFF) else Color(0x99FFFFFF)

    LiquidGlassSurface(
        modifier = modifier
            .bouncingClickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        elevation = if (selected) 8.dp else 2.dp,
        tintColor = if (selected) activeTint else inactiveTint,
        borderAlpha = if (selected) 0.8f else 0.2f
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            if (badgeCount != null && badgeCount > 0) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeCount.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
fun LiquidGlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    primary: Boolean = true
) {
    val isDark = isSystemInDarkTheme()
    val tint = if (primary) {
        MaterialTheme.colorScheme.primary.copy(alpha = if (isDark) 0.85f else 0.90f)
    } else {
        if (isDark) Color(0x33FFFFFF) else Color(0xDDFFFFFF)
    }

    LiquidGlassSurface(
        modifier = modifier.bouncingClickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        elevation = 8.dp,
        tintColor = tint
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 14.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (primary) Color.White else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (primary) Color.White else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun GlassIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .size(44.dp)
            .bouncingClickable(onClick = onClick)
    ) {
        LiquidGlassSurface(shape = RoundedCornerShape(22.dp), elevation = 4.dp) {
            icon()
        }
    }
}
