package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Liquid Glass
val glass_light_bg = Color(0xFFF6F7FB)
val glass_light_surface = Color(0xCCFFFFFF)
val glass_light_surface_strong = Color(0xF2FFFFFF)
val glass_light_text = Color(0xFF111827)
val glass_light_text_secondary = Color(0xFF6B7280)
val glass_light_border = Color(0x66FFFFFF)
val glass_light_border_subtle = Color(0x22000000)

// Dark Liquid Glass
val glass_dark_bg = Color(0xFF0B0D12)
val glass_dark_surface = Color(0x26FFFFFF)
val glass_dark_surface_strong = Color(0x3DFFFFFF)
val glass_dark_text = Color(0xFFF9FAFB)
val glass_dark_text_secondary = Color(0xFF9CA3AF)
val glass_dark_border = Color(0x33FFFFFF)
val glass_dark_border_subtle = Color(0x1AFFFFFF)

// Accent Palette
val glass_primary = Color(0xFF2563EB) // Royal blue
val glass_primary_glow = Color(0x663B82F6)
val glass_accent_lavender = Color(0xFF8B5CF6)
val glass_accent_mint = Color(0xFF10B981)
val glass_accent_rose = Color(0xFFF43F5E)
val glass_accent_amber = Color(0xFFF59E0B)

// Legacy alias definitions
val glass_background = glass_light_bg
val glass_surface = glass_light_surface
val glass_surface_strong = glass_light_surface_strong
val glass_onBackground = glass_light_text
val glass_onSurfaceVariant = glass_light_text_secondary
val glass_outline = glass_light_border
val glass_outlineVariant = glass_light_border_subtle

