package com.example.ui

import kotlinx.serialization.Serializable

sealed class Screen {
    @Serializable data object Home
    @Serializable data object Search
    @Serializable data object Collections
    @Serializable data object Favorites
    @Serializable data class Detail(val screenshotId: Long)
}
