package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ScreenshotEntity
import com.example.ui.ScreenshotViewModel
import com.example.ui.components.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    viewModel: ScreenshotViewModel,
    onNavigateToSearch: () -> Unit,
    onNavigateToDetail: (Long) -> Unit
) {
    val screenshots by viewModel.allScreenshots.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val gridState = rememberLazyStaggeredGridState()

    val isScrollingDown = remember { mutableStateOf(false) }
    var previousIndex by remember { mutableStateOf(0) }
    var previousScrollOffset by remember { mutableStateOf(0) }

    LaunchedEffect(gridState) {
        snapshotFlow { gridState.firstVisibleItemIndex to gridState.firstVisibleItemScrollOffset }
            .collect { (index, offset) ->
                if (index > previousIndex) {
                    isScrollingDown.value = true
                } else if (index < previousIndex) {
                    isScrollingDown.value = false
                } else {
                    if (offset > previousScrollOffset + 12) {
                        isScrollingDown.value = true
                    } else if (offset < previousScrollOffset - 12) {
                        isScrollingDown.value = false
                    }
                }
                previousIndex = index
                previousScrollOffset = offset
            }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyVerticalStaggeredGrid(
            state = gridState,
            columns = StaggeredGridCells.Fixed(2),
            contentPadding = PaddingValues(top = 110.dp, bottom = 120.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalItemSpacing = 12.dp,
            modifier = Modifier.fillMaxSize()
        ) {
            item(span = StaggeredGridItemSpan.FullLine) {
                HomeHeader(
                    count = screenshots.size,
                    isScanning = isScanning,
                    onSync = { viewModel.scanAndProcess() }
                )
            }

            if (screenshots.isNotEmpty()) {
                item(span = StaggeredGridItemSpan.FullLine) {
                    HeroMemory(
                        screenshot = screenshots.first(),
                        onClick = { onNavigateToDetail(screenshots.first().screenshotId) }
                    )
                }

                item(span = StaggeredGridItemSpan.FullLine) {
                    MemoryMomentsSection(
                        screenshots = screenshots,
                        onNavigateToDetail = onNavigateToDetail
                    )
                }

                item(span = StaggeredGridItemSpan.FullLine) {
                    CollectionsQuickRow(
                        screenshots = screenshots,
                        onNavigateToSearch = onNavigateToSearch
                    )
                }

                item(span = StaggeredGridItemSpan.FullLine) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Recent Memories",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "${screenshots.size} total",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                items(screenshots.drop(1), key = { it.screenshotId }) { screenshot ->
                    ScreenshotGridCard(
                        screenshot = screenshot,
                        onClick = { onNavigateToDetail(screenshot.screenshotId) }
                    )
                }
            } else {
                item(span = StaggeredGridItemSpan.FullLine) {
                    EmptyHomeState(isScanning = isScanning, onSync = { viewModel.scanAndProcess() })
                }
            }
        }

        // Floating Search Bar Launcher at Top
        AnimatedVisibility(
            visible = !isScrollingDown.value || gridState.firstVisibleItemIndex == 0,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            enter = fadeIn(animationSpec = tween(300)) + slideInVertically(initialOffsetY = { -it }),
            exit = fadeOut(animationSpec = tween(300)) + slideOutVertically(targetOffsetY = { -it })
        ) {
            LiquidGlassSearchBar(
                query = "",
                onQueryChange = {},
                placeholderText = "Search OCR, apps, notes...",
                onClick = onNavigateToSearch
            )
        }

        // Scanning Status Pill
        AnimatedVisibility(
            visible = isScanning,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 110.dp, start = 24.dp, end = 24.dp),
            enter = fadeIn() + slideInVertically(initialOffsetY = { it }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it })
        ) {
            LiquidGlassSurface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = 16.dp
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Column {
                        Text("Syncing MediaStore...", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("Extracting OCR text and auto-categorizing...", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeHeader(
    count: Int,
    isScanning: Boolean,
    onSync: () -> Unit
) {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when {
        hour < 12 -> "Good morning"
        hour < 18 -> "Good afternoon"
        else -> "Good evening"
    }

    Column(modifier = Modifier.padding(bottom = 16.dp, top = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                )
                Text(
                    text = "YOUR MEMORY JOURNAL",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "$count memories",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                GlassIconButton(onClick = onSync) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Sync",
                        tint = if (isScanning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "$greeting.",
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface,
            letterSpacing = (-1).sp
        )
    }
}

@Composable
fun HeroMemory(
    screenshot: ScreenshotEntity,
    onClick: () -> Unit
) {
    val formattedDate = remember(screenshot.dateAdded) {
        val sdf = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())
        sdf.format(Date(screenshot.dateAdded))
    }

    LiquidGlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
            .bouncingClickable(onClick = onClick),
        shape = RoundedCornerShape(32.dp),
        elevation = 16.dp
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = Uri.parse(screenshot.uri),
                contentDescription = screenshot.fileName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)),
                            startY = 100f
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primary)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = screenshot.category.ifBlank { "Recent" },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = screenshot.fileName,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun MemoryMomentsSection(
    screenshots: List<ScreenshotEntity>,
    onNavigateToDetail: (Long) -> Unit
) {
    val categories = listOf("Shopping", "Social Media", "Travel", "Education", "Food", "Messages")

    Column(modifier = Modifier.padding(top = 24.dp, bottom = 12.dp)) {
        Text(
            text = "Memory Moments",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(categories) { categoryName ->
                val matching = remember(screenshots, categoryName) {
                    screenshots.filter { it.category.equals(categoryName, ignoreCase = true) }
                }

                MemoryMomentStackCard(
                    title = categoryName,
                    count = matching.size,
                    previewScreenshots = matching.take(3),
                    onClick = {
                        if (matching.isNotEmpty()) {
                            onNavigateToDetail(matching.first().screenshotId)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun MemoryMomentStackCard(
    title: String,
    count: Int,
    previewScreenshots: List<ScreenshotEntity>,
    onClick: () -> Unit
) {
    LiquidGlassSurface(
        modifier = Modifier
            .width(220.dp)
            .height(160.dp)
            .bouncingClickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        elevation = 10.dp
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            if (previewScreenshots.isNotEmpty()) {
                previewScreenshots.forEachIndexed { index, screenshot ->
                    val rotation = if (index == 0) -6f else if (index == 1) 4f else 0f
                    val offsetX = (index * 12).dp
                    val offsetY = (index * 6).dp

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = offsetX, y = offsetY)
                            .size(60.dp, 80.dp)
                            .rotate(rotation)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                    ) {
                        AsyncImage(
                            model = Uri.parse(screenshot.uri),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }

            Column(modifier = Modifier.align(Alignment.BottomStart)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (count > 0) "$count moments" else "Explore",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun CollectionsQuickRow(
    screenshots: List<ScreenshotEntity>,
    onNavigateToSearch: () -> Unit
) {
    val quickPills = listOf("Shopping 🛒", "Code 💻", "Travel ✈️", "Social 💬", "Recipes 🍳")

    Column(modifier = Modifier.padding(vertical = 12.dp)) {
        Text(
            text = "Explore Categories",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(quickPills) { pillText ->
                val categoryName = pillText.split(" ").first()
                val count = remember(screenshots, categoryName) {
                    screenshots.count { it.category.contains(categoryName, ignoreCase = true) }
                }
                LiquidGlassChip(
                    text = pillText,
                    selected = false,
                    onClick = onNavigateToSearch,
                    badgeCount = count
                )
            }
        }
    }
}

@Composable
fun ScreenshotGridCard(
    screenshot: ScreenshotEntity,
    onClick: () -> Unit
) {
    val heightMultiplier = remember(screenshot.screenshotId) {
        val rem = (screenshot.screenshotId % 3)
        if (rem == 0L) 1.25f else if (rem == 1L) 1.0f else 0.85f
    }

    LiquidGlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.7f / heightMultiplier)
            .bouncingClickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        elevation = 8.dp
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = Uri.parse(screenshot.uri),
                contentDescription = screenshot.fileName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            if (screenshot.isFavorite) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Favorite",
                        tint = Color(0xFFF43F5E),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.40f))
                    .padding(8.dp)
            ) {
                Text(
                    text = screenshot.category.ifBlank { screenshot.fileName },
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun EmptyHomeState(
    isScanning: Boolean,
    onSync: () -> Unit
) {
    LiquidGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        elevation = 16.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🖼️", fontSize = 56.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "No Screenshots Found",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Tap the Sync button to scan your device gallery for screenshots, extract text, and automatically group them into intelligent visual memory moments.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(20.dp))
            LiquidGlassButton(
                text = if (isScanning) "Syncing..." else "Sync MediaStore",
                onClick = onSync,
                icon = Icons.Default.Sync,
                primary = true
            )
        }
    }
}
