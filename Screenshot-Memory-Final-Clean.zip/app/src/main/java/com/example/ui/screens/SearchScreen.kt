package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ScreenshotEntity
import com.example.ui.ScreenshotViewModel
import com.example.ui.components.*

@Composable
fun SearchScreen(
    viewModel: ScreenshotViewModel,
    onNavigateToDetail: (Long) -> Unit,
    onBack: () -> Unit
) {
    val query by viewModel.searchQuery.collectAsState()
    val results by viewModel.searchResults.collectAsState()
    val allScreenshots by viewModel.allScreenshots.collectAsState()

    var activeFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Shopping", "Code", "Social", "Travel", "Food", "Messages")

    val filteredResults = remember(results, activeFilter) {
        if (activeFilter == "All") results else results.filter { it.category.contains(activeFilter, ignoreCase = true) }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Search Header Bar
            LiquidGlassSurface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(32.dp),
                elevation = 16.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassIconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    TextField(
                        value = query,
                        onValueChange = { viewModel.search(it) },
                        placeholder = {
                            Text(
                                "Search OCR text, notes, apps...",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { viewModel.search("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Category Filters
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filters) { filterName ->
                    LiquidGlassChip(
                        text = filterName,
                        selected = activeFilter == filterName,
                        onClick = { activeFilter = filterName }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (query.isNotBlank()) {
                if (filteredResults.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        LiquidGlassCard(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .padding(24.dp),
                            elevation = 12.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("🔍", fontSize = 48.sp)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "No Memories Matched",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "No screenshots matched '$query'. Try searching for text inside receipts, code snippets, order confirmations, or app names.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        text = "${filteredResults.size} memories found",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    LazyVerticalStaggeredGrid(
                        columns = StaggeredGridCells.Fixed(2),
                        contentPadding = PaddingValues(bottom = 120.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalItemSpacing = 12.dp,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredResults, key = { it.screenshotId }) { screenshot ->
                            SearchScreenshotCard(
                                screenshot = screenshot,
                                query = query,
                                onClick = { onNavigateToDetail(screenshot.screenshotId) }
                            )
                        }
                    }
                }
            } else {
                // Suggested Searches Grid
                Column(modifier = Modifier.fillMaxSize()) {
                    Text(
                        text = "Suggested Memory Topics",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    val suggestions = listOf(
                        Triple("Shopping", "🛒", "Orders & Receipts"),
                        Triple("Social Media", "💬", "Chats & Posts"),
                        Triple("Travel", "✈️", "Tickets & Hotels"),
                        Triple("Education", "💻", "Code & Notes"),
                        Triple("Food", "🍳", "Recipes & Menus"),
                        Triple("Finance", "💳", "Bank & Bills")
                    )

                    LazyVerticalStaggeredGrid(
                        columns = StaggeredGridCells.Fixed(2),
                        contentPadding = PaddingValues(bottom = 120.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalItemSpacing = 12.dp,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(suggestions) { (title, emoji, desc) ->
                            val matchCount = remember(allScreenshots, title) {
                                allScreenshots.count { it.category.contains(title, ignoreCase = true) }
                            }

                            LiquidGlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp),
                                onClick = { viewModel.search(title) },
                                elevation = 8.dp
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(emoji, fontSize = 28.sp)
                                        if (matchCount > 0) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "$matchCount",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }

                                    Column {
                                        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchScreenshotCard(
    screenshot: ScreenshotEntity,
    query: String,
    onClick: () -> Unit
) {
    LiquidGlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.75f)
            .bouncingClickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        elevation = 10.dp
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = Uri.parse(screenshot.uri),
                contentDescription = screenshot.fileName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Frosted pill showing OCR match
            val snippet = remember(screenshot, query) {
                if (screenshot.ocrText.contains(query, ignoreCase = true)) {
                    val idx = screenshot.ocrText.indexOf(query, ignoreCase = true)
                    val start = (idx - 10).coerceAtLeast(0)
                    val end = (idx + query.length + 15).coerceAtMost(screenshot.ocrText.length)
                    "…${screenshot.ocrText.substring(start, end)}…"
                } else {
                    screenshot.category
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(8.dp)
            ) {
                Text(
                    text = snippet,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    maxLines = 2
                )
            }
        }
    }
}
