package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightLiquidGlassColorScheme =
  lightColorScheme(
    primary = glass_primary,
    onPrimary = Color.White,
    primaryContainer = glass_light_surface_strong,
    onPrimaryContainer = glass_light_text,
    secondaryContainer = glass_light_surface,
    onSecondaryContainer = glass_light_text,
    tertiaryContainer = glass_light_surface_strong,
    background = glass_light_bg,
    onBackground = glass_light_text,
    surface = glass_light_surface,
    onSurface = glass_light_text,
    surfaceVariant = glass_light_surface_strong,
    onSurfaceVariant = glass_light_text_secondary,
    outline = glass_light_border,
    outlineVariant = glass_light_border_subtle
  )

private val DarkLiquidGlassColorScheme =
  darkColorScheme(
    primary = glass_primary,
    onPrimary = Color.White,
    primaryContainer = glass_dark_surface_strong,
    onPrimaryContainer = glass_dark_text,
    secondaryContainer = glass_dark_surface,
    onSecondaryContainer = glass_dark_text,
    tertiaryContainer = glass_dark_surface_strong,
    background = glass_dark_bg,
    onBackground = glass_dark_text,
    surface = glass_dark_surface,
    onSurface = glass_dark_text,
    surfaceVariant = glass_dark_surface_strong,
    onSurfaceVariant = glass_dark_text_secondary,
    outline = glass_dark_border,
    outlineVariant = glass_dark_border_subtle
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkLiquidGlassColorScheme else LightLiquidGlassColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
