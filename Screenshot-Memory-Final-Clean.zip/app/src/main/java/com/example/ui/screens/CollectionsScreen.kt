package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.CollectionEntity
import com.example.data.ScreenshotEntity
import com.example.ui.ScreenshotViewModel
import com.example.ui.components.*

@Composable
fun CollectionsScreen(
    viewModel: ScreenshotViewModel,
    onNavigateToDetail: (Long) -> Unit
) {
    val screenshots by viewModel.allScreenshots.collectAsState()
    val collections by viewModel.allCollections.collectAsState()
    var selectedCollectionName by remember { mutableStateOf<String?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val defaultCategories = listOf(
        "Shopping" to "🛒",
        "Social Media" to "💬",
        "Travel" to "✈️",
        "Education" to "💻",
        "Messages" to "📱",
        "Food" to "🍳",
        "Finance" to "💳",
        "Gaming" to "🎮"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        if (selectedCollectionName != null) {
            val filterName = selectedCollectionName!!
            val filteredScreenshots = remember(screenshots, filterName) {
                screenshots.filter { 
                    it.category.equals(filterName, ignoreCase = true) || 
                    filterName.equals("All", ignoreCase = true)
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(16.dp))
                LiquidGlassToolbar(
                    title = filterName,
                    navigationIcon = {
                        GlassIconButton(onClick = { selectedCollectionName = null }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (filteredScreenshots.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("📁", fontSize = 48.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No memories in $filterName", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Screenshots categorized as $filterName will appear here.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    LazyVerticalStaggeredGrid(
                        columns = StaggeredGridCells.Fixed(2),
                        contentPadding = PaddingValues(bottom = 120.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalItemSpacing = 12.dp,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredScreenshots, key = { it.screenshotId }) { item ->
                            CollectionScreenshotThumbnail(
                                screenshot = item,
                                onClick = { onNavigateToDetail(item.screenshotId) }
                            )
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Collections", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                        Text("Curated memory stacks", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    LiquidGlassButton(
                        text = "New",
                        onClick = { showCreateDialog = true },
                        icon = Icons.Default.Add,
                        primary = true
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(bottom = 120.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(defaultCategories) { (catName, emoji) ->
                        val catScreenshots = remember(screenshots, catName) {
                            screenshots.filter { it.category.equals(catName, ignoreCase = true) }
                        }
                        CollectionStackCard(
                            title = catName,
                            emoji = emoji,
                            count = catScreenshots.size,
                            previewScreenshots = catScreenshots.take(3),
                            onClick = { selectedCollectionName = catName }
                        )
                    }

                    items(collections) { collection ->
                        CollectionStackCard(
                            title = collection.name,
                            emoji = "📁",
                            count = 0,
                            previewScreenshots = emptyList(),
                            onClick = { selectedCollectionName = collection.name }
                        )
                    }
                }
            }
        }

        if (showCreateDialog) {
            var newCollectionName by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                title = { Text("Create Collection", fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = newCollectionName,
                        onValueChange = { newCollectionName = it },
                        placeholder = { Text("Collection name (e.g., Ideas)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            if (newCollectionName.isNotBlank()) {
                                viewModel.createCollection(newCollectionName.trim())
                                showCreateDialog = false
                            }
                        }
                    ) {
                        Text("Create", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun CollectionStackCard(
    title: String,
    emoji: String,
    count: Int,
    previewScreenshots: List<ScreenshotEntity>,
    onClick: () -> Unit
) {
    LiquidGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
        onClick = onClick,
        elevation = 12.dp
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (previewScreenshots.isNotEmpty()) {
                previewScreenshots.forEachIndexed { index, screenshot ->
                    val rotation = if (index == 0) -4f else if (index == 1) 3f else 0f
                    val offsetX = (index * 8).dp
                    val offsetY = (index * 6).dp

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = offsetX, y = offsetY)
                            .size(72.dp, 100.dp)
                            .rotate(rotation)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    ) {
                        AsyncImage(
                            model = Uri.parse(screenshot.uri),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            } else {
                Text(
                    emoji,
                    fontSize = 32.sp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                )
            }

            Column(
                modifier = Modifier.align(Alignment.BottomStart)
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (count > 0) "$count memories" else "Tap to view",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun CollectionScreenshotThumbnail(
    screenshot: ScreenshotEntity,
    onClick: () -> Unit
) {
    LiquidGlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.75f)
            .bouncingClickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        elevation = 8.dp
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = Uri.parse(screenshot.uri),
                contentDescription = screenshot.fileName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.4f))
                    .padding(8.dp)
            ) {
                Text(
                    text = screenshot.fileName,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    maxLines = 1
                )
            }
        }
    }
}
