package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ui.Screen
import com.example.ui.ScreenshotViewModel
import com.example.ui.screens.DetailScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.theme.MyApplicationTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
                
                val permissionState = rememberMultiplePermissionsState(permissions)
                
                if (permissionState.allPermissionsGranted) {
                    MainApp()
                } else {
                    PermissionScreen(
                        onRequest = { permissionState.launchMultiplePermissionRequest() }
                    )
                }
            }
        }
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Welcome to Screenshot Memory", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("We need permission to access your images so we can discover and organize your screenshots.", 
                style = MaterialTheme.typography.bodyLarge,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(modifier = Modifier.height(32.dp))
            Button(onClick = onRequest) {
                Text("Grant Permissions")
            }
        }
    }
}

@Composable
fun MainApp() {
    val navController = rememberNavController()
    val viewModel: ScreenshotViewModel = viewModel()
    
    // Automatically trigger a scan when permissions are granted and app loads
    LaunchedEffect(Unit) {
        viewModel.scanAndProcess()
    }

    val currentBackStack by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStack?.destination?.route

    com.example.ui.components.AmbientBackground {
        NavHost(
            navController = navController, 
            startDestination = Screen.Home,
            enterTransition = { fadeIn(animationSpec = tween(400)) + scaleIn(initialScale = 0.95f, animationSpec = tween(400)) },
            exitTransition = { fadeOut(animationSpec = tween(300)) + scaleOut(targetScale = 1.05f, animationSpec = tween(300)) },
            popEnterTransition = { fadeIn(animationSpec = tween(400)) + scaleIn(initialScale = 1.05f, animationSpec = tween(400)) },
            popExitTransition = { fadeOut(animationSpec = tween(300)) + scaleOut(targetScale = 0.95f, animationSpec = tween(300)) }
        ) {
            composable<Screen.Home> {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToSearch = { navController.navigate(Screen.Search) },
                    onNavigateToDetail = { id -> navController.navigate(Screen.Detail(id)) }
                )
            }
            composable<Screen.Search> {
                SearchScreen(
                    viewModel = viewModel,
                    onNavigateToDetail = { id -> navController.navigate(Screen.Detail(id)) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable<Screen.Detail> { backStackEntry ->
                val detail: Screen.Detail = backStackEntry.toRoute()
                DetailScreen(
                    screenshotId = detail.screenshotId,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onNavigateToSearch = { navController.navigate(Screen.Search) }
                )
            }
        }

        if (currentRoute?.contains("Detail") != true) {
            com.example.ui.components.GlassSurface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 24.dp, vertical = 24.dp)
                    .navigationBarsPadding(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(32.dp),
                elevation = 24.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 32.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(40.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    com.example.ui.components.GlassIconButton(
                        onClick = { navController.navigate(Screen.Home) { launchSingleTop = true; popUpTo(navController.graph.startDestinationId) { inclusive = false } } }
                    ) {
                        Icon(Icons.Default.Home, contentDescription = "Home", tint = if (currentRoute?.contains("Home") == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    com.example.ui.components.GlassIconButton(
                        onClick = { navController.navigate(Screen.Search) { launchSingleTop = true; popUpTo(navController.graph.startDestinationId) { inclusive = false } } }
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = if (currentRoute?.contains("Search") == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
