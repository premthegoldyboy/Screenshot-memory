package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.ScreenshotViewModel
import com.example.ui.components.GlassSurface
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DetailScreen(
    screenshotId: Long,
    viewModel: ScreenshotViewModel,
    onBack: () -> Unit,
    onNavigateToSearch: () -> Unit
) {
    val screenshotFlow = remember(screenshotId) { viewModel.getScreenshotById(screenshotId) }
    val screenshot by screenshotFlow.collectAsState(initial = null)

    if (screenshot == null) {
        Box(modifier = Modifier.fillMaxSize()) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
        }
    } else {
        val s = screenshot!!
        var showControls by remember { mutableStateOf(true) }
        var isExpanded by remember { mutableStateOf(false) }
        
        Box(modifier = Modifier.fillMaxSize().background(Color.Black).clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) { 
            if (isExpanded) {
                isExpanded = false 
            } else {
                showControls = !showControls 
            }
        }) {
            AsyncImage(
                model = Uri.parse(s.uri),
                contentDescription = s.fileName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
            
            AnimatedVisibility(
                visible = showControls && !isExpanded,
                modifier = Modifier.align(Alignment.TopCenter),
                enter = fadeIn(animationSpec = tween(300)) + slideInVertically(initialOffsetY = { -it }),
                exit = fadeOut(animationSpec = tween(300)) + slideOutVertically(targetOffsetY = { -it })
            ) {
                GlassSurface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .statusBarsPadding(),
                    shape = RoundedCornerShape(32.dp),
                    color = Color.Black.copy(alpha = 0.3f),
                    borderColor = Color.White.copy(alpha = 0.2f),
                    elevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Text("Memory", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                        IconButton(onClick = { viewModel.toggleFavorite(s) }) {
                            Icon(
                                imageVector = if (s.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (s.isFavorite) Color(0xFFFF5252) else Color.White
                            )
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = showControls,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = fadeIn(animationSpec = tween(300)) + slideInVertically(initialOffsetY = { it }),
                exit = fadeOut(animationSpec = tween(300)) + slideOutVertically(targetOffsetY = { it })
            ) {
                GlassSurface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .navigationBarsPadding()
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { isExpanded = !isExpanded },
                    shape = RoundedCornerShape(32.dp),
                    color = Color.Black.copy(alpha = 0.4f),
                    borderColor = Color.White.copy(alpha = 0.2f),
                    elevation = 0.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                            .animateContentSize(animationSpec = tween(400))
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(s.fileName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                                Spacer(modifier = Modifier.height(8.dp))
                                val dateStr = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(Date(s.dateAdded))
                                Text("$dateStr • ${s.category}", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.7f))
                            }
                            Box(modifier = Modifier.size(36.dp).background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                                Text(if (isExpanded) "▼" else "▲", color = Color.White, fontSize = 14.sp)
                            }
                        }
                        
                        if (isExpanded) {
                            Spacer(modifier = Modifier.height(32.dp))
                            
                            var noteText by remember { mutableStateOf(s.notes) }
                            OutlinedTextField(
                                value = noteText,
                                onValueChange = { 
                                    noteText = it
                                    viewModel.addNote(s, it)
                                },
                                label = { Text("Add Note", color = Color.White.copy(alpha = 0.7f)) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.White.copy(alpha = 0.1f),
                                    unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    cursorColor = Color.White,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(16.dp)
                            )
                            
                            Spacer(modifier = Modifier.height(24.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Button(
                                    onClick = {
                                        val triggerTime = System.currentTimeMillis() + 10_000
                                        viewModel.scheduleReminder(s.screenshotId, triggerTime, "Reminder for ${s.fileName}")
                                    },
                                    modifier = Modifier.weight(1f).height(56.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                                ) {
                                    Text("Remind me later", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = {
                                        val similarityQuery = s.category.takeIf { it != "Unknown" } ?: "Screenshot"
                                        viewModel.search(similarityQuery)
                                        onNavigateToSearch()
                                    },
                                    modifier = Modifier.weight(1f).height(56.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                                ) {
                                    Text("Find similar", fontWeight = FontWeight.Bold)
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(32.dp))
                            Text("Extracted Text", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                            Spacer(modifier = Modifier.height(12.dp))
                            Box(modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).verticalScroll(rememberScrollState())) {
                                Text(
                                    text = s.ocrText.ifBlank { "No text found in this image." },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
