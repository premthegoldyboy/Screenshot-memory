package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ScreenshotEntity
import com.example.ui.ScreenshotViewModel
import com.example.ui.components.GlassSurface
import com.example.ui.components.bouncingClickable
import java.util.*

@Composable
fun HomeScreen(
    viewModel: ScreenshotViewModel,
    onNavigateToSearch: () -> Unit,
    onNavigateToDetail: (Long) -> Unit
) {
    val screenshots by viewModel.allScreenshots.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val gridState = rememberLazyStaggeredGridState()
    
    val isScrollingDown = remember { mutableStateOf(false) }
    var previousIndex by remember { mutableStateOf(0) }
    var previousScrollOffset by remember { mutableStateOf(0) }
    
    LaunchedEffect(gridState) {
        snapshotFlow { gridState.firstVisibleItemIndex to gridState.firstVisibleItemScrollOffset }
            .collect { (index, offset) ->
                if (index > previousIndex) {
                    isScrollingDown.value = true
                } else if (index < previousIndex) {
                    isScrollingDown.value = false
                } else {
                    if (offset > previousScrollOffset + 10) {
                        isScrollingDown.value = true
                    } else if (offset < previousScrollOffset - 10) {
                        isScrollingDown.value = false
                    }
                }
                previousIndex = index
                previousScrollOffset = offset
            }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyVerticalStaggeredGrid(
            state = gridState,
            columns = StaggeredGridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(top = 160.dp, bottom = 120.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalItemSpacing = 12.dp,
            modifier = Modifier.fillMaxSize()
        ) {
            item(span = StaggeredGridItemSpan.FullLine) {
                HomeHeader(isScanning = isScanning, onSync = { viewModel.scanAndProcess() }, onNavigateToSearch = onNavigateToSearch)
            }
            
            if (screenshots.isNotEmpty()) {
                item(span = StaggeredGridItemSpan.FullLine) {
                    HeroMemory(screenshot = screenshots.first(), onClick = { onNavigateToDetail(screenshots.first().screenshotId) })
                }
            }

            item(span = StaggeredGridItemSpan.FullLine) {
                MemoryMoments()
            }
            
            item(span = StaggeredGridItemSpan.FullLine) {
                CollectionsWall()
            }

            if (screenshots.isEmpty()) {
                item(span = StaggeredGridItemSpan.FullLine) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No memories found. Tap Sync to discover.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                item(span = StaggeredGridItemSpan.FullLine) {
                    Text(
                        "Recent Memories",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
                
                items(screenshots.drop(1), key = { it.screenshotId }) { screenshot ->
                    ScreenshotItem(
                        screenshot = screenshot,
                        onClick = { onNavigateToDetail(screenshot.screenshotId) }
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = !isScrollingDown.value || gridState.firstVisibleItemIndex == 0,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(animationSpec = tween(400)) + slideInVertically(initialOffsetY = { -it }),
            exit = fadeOut(animationSpec = tween(400)) + slideOutVertically(targetOffsetY = { -it })
        ) {
            GlassSurface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp)
                    .statusBarsPadding()
                    .bouncingClickable { onNavigateToSearch() },
                shape = RoundedCornerShape(32.dp),
                elevation = 24.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Search anything you remember...", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }

        AnimatedVisibility(
            visible = isScanning,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 120.dp).padding(horizontal = 24.dp),
            enter = fadeIn() + slideInVertically(initialOffsetY = { it }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it })
        ) {
            GlassSurface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = 16.dp
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    Column {
                        Text("Discovering Memories", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("Extracting text and organizing...", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeHeader(isScanning: Boolean, onSync: () -> Unit, onNavigateToSearch: () -> Unit) {
    val time = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when {
        time < 12 -> "Good morning."
        time < 18 -> "Good afternoon."
        else -> "Good evening."
    }

    Column(modifier = Modifier.padding(bottom = 24.dp, top = 16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Your visual memory", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            IconButton(onClick = onSync) {
                Icon(Icons.Default.Sync, contentDescription = "Sync", tint = if(isScanning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(greeting, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.SemiBold, letterSpacing = (-1).sp)
    }
}

@Composable
fun HeroMemory(screenshot: ScreenshotEntity, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.85f)
            .bouncingClickable { onClick() }
    ) {
        GlassSurface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(32.dp),
            elevation = 16.dp
        ) {
            AsyncImage(
                model = Uri.parse(screenshot.uri),
                contentDescription = screenshot.fileName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(modifier = Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)),
                    startY = 200f
                )
            ))
            
            GlassSurface(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(24.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color.Black.copy(alpha = 0.2f),
                borderColor = Color.White.copy(alpha = 0.3f),
                elevation = 0.dp
            ) {
                Column(Modifier.padding(16.dp).fillMaxWidth()) {
                    val title = screenshot.category.takeIf { it != "Unknown" } ?: "Recent Memory"
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(screenshot.fileName, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f))
                }
            }
        }
    }
}

@Composable
fun MemoryMoments() {
    Column(modifier = Modifier.padding(top = 40.dp, bottom = 16.dp)) {
        Text(
            "Memory Moments",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        androidx.compose.foundation.lazy.LazyRow(
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(3) { index ->
                val title = listOf("Bike Research", "App Ideas", "Recipes")[index]
                val count = listOf("12 items", "42 items", "8 items")[index]
                GlassSurface(
                    modifier = Modifier.width(260.dp).height(180.dp),
                    shape = RoundedCornerShape(24.dp),
                    elevation = 8.dp
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)))
                        Column(
                            modifier = Modifier.align(Alignment.BottomStart).padding(20.dp)
                        ) {
                            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(count, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CollectionsWall() {
    Column(modifier = Modifier.padding(vertical = 16.dp)) {
        Text(
            "Collections",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        androidx.compose.foundation.lazy.LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(4) { index ->
                val text = listOf("Favorites", "Shopping", "Code", "Travel")[index]
                GlassSurface(
                    modifier = Modifier.height(64.dp).bouncingClickable { },
                    shape = RoundedCornerShape(32.dp),
                    elevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(12.dp).clip(androidx.compose.foundation.shape.CircleShape).background(MaterialTheme.colorScheme.primary))
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

@Composable
fun ScreenshotItem(screenshot: ScreenshotEntity, onClick: () -> Unit) {
    val heightMultiplier = remember(screenshot.screenshotId) { 
        val h = (screenshot.screenshotId % 3)
        if (h == 0L) 1.2f else if (h == 1L) 1.0f else 0.8f 
    }
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.7f / heightMultiplier)
            .bouncingClickable(onClick = onClick)
    ) {
        GlassSurface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(20.dp),
            elevation = 8.dp
        ) {
            AsyncImage(
                model = Uri.parse(screenshot.uri),
                contentDescription = screenshot.fileName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    }
}
