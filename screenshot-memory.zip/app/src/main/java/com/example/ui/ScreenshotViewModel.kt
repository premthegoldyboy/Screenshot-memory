package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

class ScreenshotViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val repository = ScreenshotRepository(db.screenshotDao(), db.tagDao(), db.collectionDao())
    private val scanner = MediaStoreScanner(application, repository)

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    val allScreenshots = repository.allScreenshots.stateIn(
        viewModelScope, SharingStarted.Lazily, emptyList()
    )

    val allCollections = repository.allCollections.stateIn(
        viewModelScope, SharingStarted.Lazily, emptyList()
    )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val searchResults = _searchQuery.flatMapLatest { query ->
        if (query.isBlank()) {
            flowOf(emptyList())
        } else {
            repository.searchScreenshots(query)
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun scanAndProcess() {
        if (_isScanning.value) return
        _isScanning.value = true
        viewModelScope.launch {
            try {
                scanner.scanScreenshots()
                scanner.processPendingOcr()
            } finally {
                _isScanning.value = false
            }
        }
    }

    fun search(query: String) {
        _searchQuery.value = query
    }

    fun toggleFavorite(screenshot: ScreenshotEntity) {
        viewModelScope.launch {
            repository.updateScreenshot(screenshot.copy(isFavorite = !screenshot.isFavorite))
        }
    }

    fun addNote(screenshot: ScreenshotEntity, note: String) {
        viewModelScope.launch {
            repository.updateScreenshot(screenshot.copy(notes = note))
        }
    }

    fun createCollection(name: String) {
        viewModelScope.launch {
            repository.createCollection(name)
        }
    }

    fun addScreenshotToCollection(screenshotId: Long, collectionId: Long) {
        viewModelScope.launch {
            repository.addScreenshotToCollection(screenshotId, collectionId)
        }
    }
    
    fun scheduleReminder(screenshotId: Long, timeMs: Long, text: String) {
        val context = getApplication<Application>()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, com.example.ReminderReceiver::class.java).apply {
            putExtra("screenshotId", screenshotId)
            putExtra("text", text)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            screenshotId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        try {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeMs, pendingIntent)
        } catch (e: SecurityException) {
            // Can't schedule exact alarms on Android 14+ without permission, fallback to inexact
            alarmManager.setWindow(AlarmManager.RTC_WAKEUP, timeMs, 1000 * 60 * 10, pendingIntent)
        }
    }
    
    fun getScreenshotById(id: Long) = repository.getScreenshotById(id)
}
