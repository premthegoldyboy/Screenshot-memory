package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun AmbientBackground(content: @Composable BoxScope.() -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient")
    val offset1 by infiniteTransition.animateFloat(
        initialValue = -500f, targetValue = 1500f,
        animationSpec = infiniteRepeatable(tween(15000, easing = LinearEasing), RepeatMode.Reverse),
        label = "offset1"
    )
    val offset2 by infiniteTransition.animateFloat(
        initialValue = 1500f, targetValue = -500f,
        animationSpec = infiniteRepeatable(tween(20000, easing = LinearEasing), RepeatMode.Reverse),
        label = "offset2"
    )

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFFF9F9FC))) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val color1 = Color(0x33A0C4FF) // Icy blue
            val color2 = Color(0x33BDB2FF) // Lavender
            val color3 = Color(0x33FFC6FF) // Peach
            val color4 = Color(0x33FDFFB6) // Champagne

            drawCircle(
                brush = Brush.radialGradient(listOf(color1, Color.Transparent)),
                radius = size.maxDimension * 0.6f,
                center = androidx.compose.ui.geometry.Offset(offset1, offset2)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(color2, Color.Transparent)),
                radius = size.maxDimension * 0.7f,
                center = androidx.compose.ui.geometry.Offset(size.width - offset2, size.height - offset1)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(color3, Color.Transparent)),
                radius = size.maxDimension * 0.5f,
                center = androidx.compose.ui.geometry.Offset(size.width / 2 + offset1 / 2, size.height / 2 - offset2 / 2)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(color4, Color.Transparent)),
                radius = size.maxDimension * 0.8f,
                center = androidx.compose.ui.geometry.Offset(size.width / 2 - offset1 / 2, size.height / 2 + offset2 / 2)
            )
        }
        content()
    }
}

@Composable
fun Modifier.bouncingClickable(
    enabled: Boolean = true,
    onClick: () -> Unit
): Modifier {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "scale"
    )

    return this
        .scale(scale)
        .pointerInput(enabled) {
            if (enabled) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        tryAwaitRelease()
                        isPressed = false
                    },
                    onTap = {
                        onClick()
                    }
                )
            }
        }
}

@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    color: Color = Color.Transparent, 
    borderColor: Color = Color.White.copy(alpha = 0.5f),
    elevation: Dp = 16.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val glassBrush = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.6f),
            Color.White.copy(alpha = 0.15f)
        )
    )
    val borderBrush = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.8f),
            Color.White.copy(alpha = 0.1f)
        )
    )

    Box(
        modifier = modifier
            .shadow(elevation, shape, spotColor = Color(0x33000000), ambientColor = Color(0x11000000))
            .clip(shape)
            .background(glassBrush)
            .border(1.dp, borderBrush, shape),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
fun GlassIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .size(48.dp)
            .bouncingClickable(onClick = onClick)
    ) {
        GlassSurface(shape = RoundedCornerShape(24.dp), elevation = 4.dp) {
            icon()
        }
    }
}

