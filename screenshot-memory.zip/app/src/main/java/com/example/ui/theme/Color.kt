package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val glass_background = Color(0xFFF5F5F7) // Very light gray/off-white
val glass_surface = Color(0xB3FFFFFF) // Semi-transparent white
val glass_surface_strong = Color(0xE6FFFFFF)
val glass_onBackground = Color(0xFF1D1D1F) // Dark text
val glass_onSurfaceVariant = Color(0xFF86868B)
val glass_primary = Color(0xFF007AFF) // Soft blue accent
val glass_outline = Color(0x4DFFFFFF)
val glass_outlineVariant = Color(0x33FFFFFF)
