package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LiquidGlassColorScheme =
  lightColorScheme(
    primary = glass_primary,
    onPrimary = Color.White,
    primaryContainer = glass_surface_strong,
    onPrimaryContainer = glass_onBackground,
    secondaryContainer = glass_surface,
    onSecondaryContainer = glass_onBackground,
    tertiaryContainer = glass_surface_strong,
    background = glass_background,
    onBackground = glass_onBackground,
    surface = glass_surface,
    onSurface = glass_onBackground,
    surfaceVariant = glass_surface_strong,
    onSurfaceVariant = glass_onSurfaceVariant,
    outline = glass_outline,
    outlineVariant = glass_outlineVariant
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disabling dynamic colors by default to strictly enforce Glass theme
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  // Always use the Glass scheme to force the styling per design instructions
  val colorScheme = LiquidGlassColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
