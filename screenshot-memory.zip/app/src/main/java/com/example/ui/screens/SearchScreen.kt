package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.ScreenshotEntity
import com.example.ui.ScreenshotViewModel
import com.example.ui.components.GlassSurface
import com.example.ui.components.bouncingClickable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: ScreenshotViewModel,
    onNavigateToDetail: (Long) -> Unit,
    onBack: () -> Unit
) {
    val query by viewModel.searchQuery.collectAsState()
    val results by viewModel.searchResults.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        LazyVerticalStaggeredGrid(
            columns = StaggeredGridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(top = 180.dp, bottom = 120.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalItemSpacing = 12.dp,
            modifier = Modifier.fillMaxSize()
        ) {
            if (query.isNotBlank()) {
                item(span = StaggeredGridItemSpan.FullLine) {
                    Text(
                        text = if (results.isEmpty()) "No results found." else "${results.size} memories",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
                items(results, key = { it.screenshotId }) { screenshot ->
                    SearchScreenshotItem(
                        screenshot = screenshot,
                        onClick = { onNavigateToDetail(screenshot.screenshotId) }
                    )
                }
            }
        }

        GlassSurface(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .statusBarsPadding(),
            shape = RoundedCornerShape(32.dp),
            elevation = 24.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (query.isBlank()) {
                    Text("What do you remember?", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 24.dp))
                }
                
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    TextField(
                        value = query,
                        onValueChange = { viewModel.search(it) },
                        placeholder = { Text("Try 'motorcycle' or 'receipt'") },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { viewModel.search("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        
        if (query.isBlank()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 180.dp, start = 24.dp, end = 24.dp)
            ) {
                Text("Suggested Searches", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(24.dp))
                
                val suggestions = listOf("Shopping" to "🛒", "Messages" to "💬", "Travel" to "✈️", "Code" to "💻")
                suggestions.chunked(2).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        rowItems.forEach { (suggestion, emoji) ->
                            GlassSurface(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(100.dp)
                                    .bouncingClickable { viewModel.search(suggestion) },
                                shape = RoundedCornerShape(28.dp),
                                elevation = 8.dp
                            ) {
                                Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Bottom) {
                                    Text(emoji, style = MaterialTheme.typography.headlineSmall)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = suggestion,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchScreenshotItem(screenshot: ScreenshotEntity, onClick: () -> Unit) {
    val heightMultiplier = remember(screenshot.screenshotId) { 
        val h = (screenshot.screenshotId % 3)
        if (h == 0L) 1.2f else if (h == 1L) 1.0f else 0.8f 
    }
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.7f / heightMultiplier)
            .bouncingClickable(onClick = onClick)
    ) {
        GlassSurface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(20.dp),
            elevation = 8.dp
        ) {
            AsyncImage(
                model = Uri.parse(screenshot.uri),
                contentDescription = screenshot.fileName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Explanation pill
            Box(
                modifier = Modifier.align(Alignment.BottomStart).padding(8.dp)
                    .background(Color.White.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(screenshot.category.takeIf { it != "Unknown" } ?: "Matched", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
    }
}
