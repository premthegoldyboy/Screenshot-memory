package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index
import androidx.room.Junction
import androidx.room.Relation
import androidx.room.Embedded

@Entity(
    tableName = "screenshots",
    indices = [Index(value = ["uri"], unique = true)]
)
data class ScreenshotEntity(
    @PrimaryKey(autoGenerate = true) val screenshotId: Long = 0,
    val uri: String, // String representation of the Uri
    val fileName: String,
    val dateAdded: Long,
    val ocrText: String = "",
    val category: String = "Unknown",
    val notes: String = "",
    val isFavorite: Boolean = false,
    val isIndexed: Boolean = false
)

@Entity(
    tableName = "tags",
    indices = [Index(value = ["name"], unique = true)]
)
data class TagEntity(
    @PrimaryKey(autoGenerate = true) val tagId: Long = 0,
    val name: String
)

@Entity(
    tableName = "screenshot_tags",
    primaryKeys = ["screenshotId", "tagId"],
    indices = [Index(value = ["tagId"])]
)
data class ScreenshotTagCrossRef(
    val screenshotId: Long,
    val tagId: Long
)

@Entity(
    tableName = "collections",
    indices = [Index(value = ["name"], unique = true)]
)
data class CollectionEntity(
    @PrimaryKey(autoGenerate = true) val collectionId: Long = 0,
    val name: String,
    val coverUri: String? = null
)

@Entity(
    tableName = "screenshot_collections",
    primaryKeys = ["screenshotId", "collectionId"],
    indices = [Index(value = ["collectionId"])]
)
data class ScreenshotCollectionCrossRef(
    val screenshotId: Long,
    val collectionId: Long
)

// Relationships
data class ScreenshotWithTags(
    @Embedded val screenshot: ScreenshotEntity,
    @Relation(
        parentColumn = "screenshotId",
        entityColumn = "tagId",
        associateBy = Junction(ScreenshotTagCrossRef::class)
    )
    val tags: List<TagEntity>
)

data class CollectionWithScreenshots(
    @Embedded val collection: CollectionEntity,
    @Relation(
        parentColumn = "collectionId",
        entityColumn = "screenshotId",
        associateBy = Junction(ScreenshotCollectionCrossRef::class)
    )
    val screenshots: List<ScreenshotEntity>
)
