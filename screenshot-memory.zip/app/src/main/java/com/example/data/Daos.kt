package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ScreenshotDao {
    @Query("SELECT * FROM screenshots ORDER BY dateAdded DESC")
    fun getAllScreenshots(): Flow<List<ScreenshotEntity>>

    @Query("SELECT * FROM screenshots WHERE isFavorite = 1 ORDER BY dateAdded DESC")
    fun getFavorites(): Flow<List<ScreenshotEntity>>

    @Query("SELECT * FROM screenshots WHERE uri = :uri")
    suspend fun getByUri(uri: String): ScreenshotEntity?

    @Query("SELECT * FROM screenshots WHERE screenshotId = :id")
    fun getById(id: Long): Flow<ScreenshotEntity?>

    @Query("SELECT * FROM screenshots WHERE isIndexed = 0 LIMIT 10")
    suspend fun getUnindexedScreenshots(): List<ScreenshotEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(screenshot: ScreenshotEntity): Long

    @Update
    suspend fun update(screenshot: ScreenshotEntity)

    @Delete
    suspend fun delete(screenshot: ScreenshotEntity)

    @Query("SELECT * FROM screenshots WHERE ocrText LIKE '%' || :query || '%' OR notes LIKE '%' || :query || '%' OR fileName LIKE '%' || :query || '%' ORDER BY dateAdded DESC")
    fun search(query: String): Flow<List<ScreenshotEntity>>
    
    @Transaction
    @Query("SELECT * FROM screenshots WHERE screenshotId = :id")
    fun getScreenshotWithTags(id: Long): Flow<ScreenshotWithTags?>
}

@Dao
interface TagDao {
    @Query("SELECT * FROM tags ORDER BY name ASC")
    fun getAllTags(): Flow<List<TagEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTag(tag: TagEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertScreenshotTagCrossRef(crossRef: ScreenshotTagCrossRef)

    @Delete
    suspend fun removeScreenshotTagCrossRef(crossRef: ScreenshotTagCrossRef)
    
    @Query("SELECT * FROM tags WHERE name = :name LIMIT 1")
    suspend fun getTagByName(name: String): TagEntity?
}

@Dao
interface CollectionDao {
    @Query("SELECT * FROM collections ORDER BY name ASC")
    fun getAllCollections(): Flow<List<CollectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollection(collection: CollectionEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertScreenshotCollectionCrossRef(crossRef: ScreenshotCollectionCrossRef)
    
    @Delete
    suspend fun removeScreenshotCollectionCrossRef(crossRef: ScreenshotCollectionCrossRef)

    @Transaction
    @Query("SELECT * FROM collections WHERE collectionId = :id")
    fun getCollectionWithScreenshots(id: Long): Flow<CollectionWithScreenshots>
    
    @Query("SELECT * FROM collections WHERE name = :name LIMIT 1")
    suspend fun getCollectionByName(name: String): CollectionEntity?
}
