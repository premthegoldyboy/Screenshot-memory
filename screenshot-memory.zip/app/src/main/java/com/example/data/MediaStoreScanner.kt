package com.example.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.IOException

class MediaStoreScanner(
    private val context: Context,
    private val repository: ScreenshotRepository
) {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun scanScreenshots() = withContext(Dispatchers.IO) {
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.RELATIVE_PATH
        )

        // Only query files containing "Screenshots" in their path
        val selection = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?"
        val selectionArgs = arrayOf("%Screenshots%")
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

        context.contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            sortOrder
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val dateAddedColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val name = cursor.getString(nameColumn) ?: "Unknown"
                val dateAdded = cursor.getLong(dateAddedColumn) * 1000L // Convert to ms
                
                val contentUri: Uri = ContentUris.withAppendedId(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    id
                )

                val uriString = contentUri.toString()
                val existing = repository.getScreenshotByUri(uriString)

                if (existing == null) {
                    // New screenshot found
                    val newEntity = ScreenshotEntity(
                        uri = uriString,
                        fileName = name,
                        dateAdded = dateAdded,
                        isIndexed = false
                    )
                    repository.insertScreenshot(newEntity)
                }
            }
        }
    }

    suspend fun processPendingOcr() = withContext(Dispatchers.IO) {
        var unindexed = repository.getUnindexedScreenshots()
        while (unindexed.isNotEmpty()) {
            for (screenshot in unindexed) {
                val text = extractTextFromUri(Uri.parse(screenshot.uri))
                val category = getCategoryFromText(text)
                
                val updated = screenshot.copy(
                    ocrText = text,
                    category = category,
                    isIndexed = true
                )
                repository.updateScreenshot(updated)
            }
            unindexed = repository.getUnindexedScreenshots()
        }
    }

    suspend fun extractTextFromUri(uri: Uri): String {
        return try {
            val image = InputImage.fromFilePath(context, uri)
            val result = recognizer.process(image).await()
            result.text
        } catch (e: Exception) {
            Log.e("MediaStoreScanner", "Error extracting text", e)
            ""
        }
    }
    
    fun getCategoryFromText(text: String): String {
        val lower = text.lowercase()
        return when {
            lower.contains("amazon") || lower.contains("flipkart") || lower.contains("price") || lower.contains("buy") || lower.contains("₹") || lower.contains("$") -> "Shopping"
            lower.contains("instagram") || lower.contains("facebook") || lower.contains("twitter") || lower.contains("tiktok") -> "Social Media"
            lower.contains("message") || lower.contains("whatsapp") || lower.contains("chat") -> "Messages"
            lower.contains("recipe") || lower.contains("cook") || lower.contains("ingredients") -> "Food"
            lower.contains("flight") || lower.contains("hotel") || lower.contains("booking") || lower.contains("travel") -> "Travel"
            lower.contains("bank") || lower.contains("payment") || lower.contains("transfer") || lower.contains("account") -> "Finance"
            lower.contains("code") || lower.contains("fun ") || lower.contains("class ") -> "Education"
            lower.contains("game") || lower.contains("score") || lower.contains("level") -> "Gaming"
            else -> "Unknown"
        }
    }
}
