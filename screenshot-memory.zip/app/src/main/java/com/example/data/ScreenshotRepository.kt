package com.example.data

import kotlinx.coroutines.flow.Flow

class ScreenshotRepository(
    private val screenshotDao: ScreenshotDao,
    private val tagDao: TagDao,
    private val collectionDao: CollectionDao
) {
    val allScreenshots: Flow<List<ScreenshotEntity>> = screenshotDao.getAllScreenshots()
    val favoriteScreenshots: Flow<List<ScreenshotEntity>> = screenshotDao.getFavorites()
    val allCollections: Flow<List<CollectionEntity>> = collectionDao.getAllCollections()
    val allTags: Flow<List<TagEntity>> = tagDao.getAllTags()

    suspend fun insertScreenshot(screenshot: ScreenshotEntity): Long {
        return screenshotDao.insert(screenshot)
    }

    suspend fun updateScreenshot(screenshot: ScreenshotEntity) {
        screenshotDao.update(screenshot)
    }

    suspend fun deleteScreenshot(screenshot: ScreenshotEntity) {
        screenshotDao.delete(screenshot)
    }

    suspend fun getScreenshotByUri(uri: String): ScreenshotEntity? {
        return screenshotDao.getByUri(uri)
    }

    fun getScreenshotById(id: Long): Flow<ScreenshotEntity?> {
        return screenshotDao.getById(id)
    }

    fun searchScreenshots(query: String): Flow<List<ScreenshotEntity>> {
        return screenshotDao.search(query)
    }

    suspend fun getUnindexedScreenshots(): List<ScreenshotEntity> {
        return screenshotDao.getUnindexedScreenshots()
    }

    fun getScreenshotWithTags(id: Long): Flow<ScreenshotWithTags?> {
        return screenshotDao.getScreenshotWithTags(id)
    }

    suspend fun addTagToScreenshot(screenshotId: Long, tagName: String) {
        var tag = tagDao.getTagByName(tagName)
        var tagId = tag?.tagId
        if (tagId == null) {
            tagId = tagDao.insertTag(TagEntity(name = tagName))
        }
        tagDao.insertScreenshotTagCrossRef(ScreenshotTagCrossRef(screenshotId, tagId))
    }

    suspend fun removeTagFromScreenshot(screenshotId: Long, tagId: Long) {
        tagDao.removeScreenshotTagCrossRef(ScreenshotTagCrossRef(screenshotId, tagId))
    }

    suspend fun createCollection(name: String): Long {
        return collectionDao.insertCollection(CollectionEntity(name = name))
    }

    suspend fun addScreenshotToCollection(screenshotId: Long, collectionId: Long) {
        collectionDao.insertScreenshotCollectionCrossRef(ScreenshotCollectionCrossRef(screenshotId, collectionId))
    }

    fun getCollectionWithScreenshots(collectionId: Long): Flow<CollectionWithScreenshots> {
        return collectionDao.getCollectionWithScreenshots(collectionId)
    }
}
